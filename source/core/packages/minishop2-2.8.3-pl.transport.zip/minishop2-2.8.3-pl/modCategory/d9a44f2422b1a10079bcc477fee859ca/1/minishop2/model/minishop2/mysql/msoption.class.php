<?php
require_once (dirname(__DIR__) . '/msoption.class.php');
class msOption_mysql extends msOption {}