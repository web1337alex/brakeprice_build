<?php
require_once (dirname(__DIR__) . '/msdeliverymember.class.php');
class msDeliveryMember_mysql extends msDeliveryMember {}