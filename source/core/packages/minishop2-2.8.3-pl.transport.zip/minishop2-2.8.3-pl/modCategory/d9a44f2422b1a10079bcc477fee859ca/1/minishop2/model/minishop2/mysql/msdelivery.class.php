<?php
require_once (dirname(__DIR__) . '/msdelivery.class.php');
class msDelivery_mysql extends msDelivery {}