<?php
require_once (dirname(__DIR__) . '/msproductdata.class.php');
class msProductData_mysql extends msProductData {}