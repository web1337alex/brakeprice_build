<?php
require_once (dirname(__DIR__) . '/mscustomerprofile.class.php');
class msCustomerProfile_mysql extends msCustomerProfile {}